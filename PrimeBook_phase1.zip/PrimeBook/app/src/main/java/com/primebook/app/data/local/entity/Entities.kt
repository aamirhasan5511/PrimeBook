package com.primebook.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// Money is stored in paise (Long) to avoid floating-point errors. Quantities are Double.

@Entity(tableName = "categories", indices = [Index(value = ["name"], unique = true)])
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(
    tableName = "products",
    indices = [Index("name"), Index("sku"), Index("categoryId"), Index("isDeleted")]
)
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val categoryId: Long? = null,
    val sku: String = "",
    val mrp: Long = 0,
    val purchasePrice: Long = 0,
    val sellingPrice: Long = 0,
    val currentStock: Double = 0.0,
    val minStock: Double = 0.0,
    val unit: String = "pcs",
    val description: String = "",
    val isDeleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/** type: IN, OUT, ADJUST. quantity is signed delta (+ve in, -ve out). */
@Entity(
    tableName = "stock_history",
    indices = [Index("productId"), Index("createdAt"), Index("refNumber")]
)
data class StockHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val productName: String,
    val quantity: Double,
    val stockAfter: Double,
    val type: String,
    val reason: String,
    val refType: String = "",      // SALE, PURCHASE, MANUAL, OPENING
    val refId: Long = 0,
    val refNumber: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers", indices = [Index("name"), Index("mobile")])
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val mobile: String = "",
    val address: String = "",
    val isDeleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "suppliers", indices = [Index("name")])
data class SupplierEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val mobile: String = "",
    val address: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "sales",
    indices = [Index(value = ["invoiceNumber"], unique = true), Index("customerId"), Index("createdAt")]
)
data class SaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNumber: String,
    val customerId: Long? = null,       // null = walk-in
    val customerName: String = "Walk-in Customer",
    val customerMobile: String = "",
    val customerAddress: String = "",
    val subtotal: Long,
    val discount: Long = 0,
    val roundOff: Long = 0,
    val total: Long,
    val cashPaid: Long = 0,
    val upiPaid: Long = 0,
    val creditAmount: Long = 0,         // remaining on this bill, stored separately from sale amount
    val profit: Long = 0,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val totalPaid: Long get() = cashPaid + upiPaid
}

@Entity(
    tableName = "sale_items",
    foreignKeys = [ForeignKey(SaleEntity::class, ["id"], ["saleId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("saleId"), Index("productId")]
)
data class SaleItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val productName: String,
    val unit: String,
    val quantity: Double,
    val rate: Long,
    val discount: Long = 0,
    val amount: Long,
    val costPrice: Long,                // purchase cost snapshot at time of sale
    val profit: Long
)

@Entity(
    tableName = "purchases",
    indices = [Index("supplierId"), Index("purchaseDate"), Index("supplierBillNumber")]
)
data class PurchaseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplierId: Long? = null,
    val supplierName: String = "",
    val supplierBillNumber: String = "",
    val purchaseDate: Long,
    val total: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "purchase_items",
    foreignKeys = [ForeignKey(PurchaseEntity::class, ["id"], ["purchaseId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("purchaseId"), Index("productId")]
)
data class PurchaseItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseId: Long,
    val productId: Long,
    val productName: String,
    val quantity: Double,
    val purchasePrice: Long,
    val total: Long
)

/** Append-only purchase price history. Never overwritten. */
@Entity(tableName = "purchase_price_history", indices = [Index("productId"), Index("purchaseId")])
data class PurchasePriceHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val purchaseId: Long,
    val price: Long,
    val date: Long
)

/** Payments received from customers against outstanding credit. method: CASH or UPI. */
@Entity(tableName = "customer_payments", indices = [Index("customerId"), Index("createdAt")])
data class CustomerPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val amount: Long,
    val method: String,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/** Single-row table (id = 1) guaranteeing duplicate-free invoice numbers. */
@Entity(tableName = "invoice_counter")
data class InvoiceCounterEntity(
    @PrimaryKey val id: Int = 1,
    val prefix: String = "INV-",
    val nextNumber: Long = 1,
    val padding: Int = 4
)

/** Single-row table (id = 1). */
@Entity(tableName = "business_profile")
data class BusinessProfileEntity(
    @PrimaryKey val id: Int = 1,
    val shopName: String = "",
    val ownerName: String = "",
    val address: String = "",
    val phone: String = "",
    val email: String = "",
    val logoPath: String = "",
    val invoiceFooter: String = "Thank you! Visit again.",
    val terms: String = ""
)

@Entity(tableName = "app_settings")
data class AppSettingEntity(
    @PrimaryKey val key: String,
    val value: String
)
