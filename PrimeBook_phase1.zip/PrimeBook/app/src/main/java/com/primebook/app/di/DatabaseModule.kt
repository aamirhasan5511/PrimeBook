package com.primebook.app.di

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.primebook.app.data.local.PrimeBookDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): PrimeBookDatabase =
        Room.databaseBuilder(context, PrimeBookDatabase::class.java, PrimeBookDatabase.NAME)
            .addCallback(object : RoomDatabase.Callback() {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    db.execSQL("INSERT OR IGNORE INTO invoice_counter (id, prefix, nextNumber, padding) VALUES (1, 'INV-', 1, 4)")
                    db.execSQL(
                        "INSERT OR IGNORE INTO business_profile (id, shopName, ownerName, address, phone, email, logoPath, invoiceFooter, terms) " +
                            "VALUES (1, '', '', '', '', '', '', 'Thank you! Visit again.', '')"
                    )
                }
            })
            .build()

    @Provides fun categoryDao(db: PrimeBookDatabase) = db.categoryDao()
    @Provides fun productDao(db: PrimeBookDatabase) = db.productDao()
    @Provides fun stockHistoryDao(db: PrimeBookDatabase) = db.stockHistoryDao()
    @Provides fun customerDao(db: PrimeBookDatabase) = db.customerDao()
    @Provides fun supplierDao(db: PrimeBookDatabase) = db.supplierDao()
    @Provides fun saleDao(db: PrimeBookDatabase) = db.saleDao()
    @Provides fun purchaseDao(db: PrimeBookDatabase) = db.purchaseDao()
    @Provides fun customerPaymentDao(db: PrimeBookDatabase) = db.customerPaymentDao()
    @Provides fun invoiceCounterDao(db: PrimeBookDatabase) = db.invoiceCounterDao()
    @Provides fun businessProfileDao(db: PrimeBookDatabase) = db.businessProfileDao()
    @Provides fun appSettingDao(db: PrimeBookDatabase) = db.appSettingDao()
}
