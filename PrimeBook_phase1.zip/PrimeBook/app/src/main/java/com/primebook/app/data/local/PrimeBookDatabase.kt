package com.primebook.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.primebook.app.data.local.dao.*
import com.primebook.app.data.local.entity.*

@Database(
    entities = [
        CategoryEntity::class, ProductEntity::class, StockHistoryEntity::class,
        CustomerEntity::class, SupplierEntity::class,
        SaleEntity::class, SaleItemEntity::class,
        PurchaseEntity::class, PurchaseItemEntity::class, PurchasePriceHistoryEntity::class,
        CustomerPaymentEntity::class, InvoiceCounterEntity::class,
        BusinessProfileEntity::class, AppSettingEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class PrimeBookDatabase : RoomDatabase() {
    abstract fun categoryDao(): CategoryDao
    abstract fun productDao(): ProductDao
    abstract fun stockHistoryDao(): StockHistoryDao
    abstract fun customerDao(): CustomerDao
    abstract fun supplierDao(): SupplierDao
    abstract fun saleDao(): SaleDao
    abstract fun purchaseDao(): PurchaseDao
    abstract fun customerPaymentDao(): CustomerPaymentDao
    abstract fun invoiceCounterDao(): InvoiceCounterDao
    abstract fun businessProfileDao(): BusinessProfileDao
    abstract fun appSettingDao(): AppSettingDao

    companion object {
        const val NAME = "primebook.db"
    }
}
