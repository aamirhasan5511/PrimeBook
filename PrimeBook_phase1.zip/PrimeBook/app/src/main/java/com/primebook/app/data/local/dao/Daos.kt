package com.primebook.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.primebook.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(c: CategoryEntity): Long
    @Query("SELECT * FROM categories ORDER BY name") fun observeAll(): Flow<List<CategoryEntity>>
    @Query("SELECT * FROM categories WHERE name = :name LIMIT 1") suspend fun findByName(name: String): CategoryEntity?
    @Delete suspend fun delete(c: CategoryEntity)
}

@Dao
interface ProductDao {
    @Insert suspend fun insert(p: ProductEntity): Long
    @Update suspend fun update(p: ProductEntity)
    @Query("SELECT * FROM products WHERE id = :id") suspend fun getById(id: Long): ProductEntity?
    @Query("UPDATE products SET isDeleted = 1, updatedAt = :now WHERE id = :id")
    suspend fun softDelete(id: Long, now: Long)

    /** statusFilter: 0 = all, 1 = in stock, 2 = low stock, 3 = out of stock */
    @Query(
        """SELECT * FROM products WHERE isDeleted = 0
           AND (:q = '' OR name LIKE '%' || :q || '%' OR sku LIKE '%' || :q || '%')
           AND (:categoryId IS NULL OR categoryId = :categoryId)
           AND (:statusFilter = 0
                OR (:statusFilter = 1 AND currentStock > 0)
                OR (:statusFilter = 2 AND currentStock > 0 AND currentStock <= minStock)
                OR (:statusFilter = 3 AND currentStock <= 0))
           ORDER BY name COLLATE NOCASE"""
    )
    fun observe(q: String, categoryId: Long?, statusFilter: Int): Flow<List<ProductEntity>>

    @Query("UPDATE products SET currentStock = currentStock + :delta, updatedAt = :now WHERE id = :id")
    suspend fun changeStock(id: Long, delta: Double, now: Long)

    @Query("UPDATE products SET purchasePrice = :price, updatedAt = :now WHERE id = :id")
    suspend fun setPurchasePrice(id: Long, price: Long, now: Long)

    @Query("SELECT COUNT(*) FROM products WHERE isDeleted = 0") fun observeCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM products WHERE isDeleted = 0 AND currentStock > 0 AND currentStock <= minStock")
    fun observeLowStockCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM products WHERE isDeleted = 0 AND currentStock <= 0")
    fun observeOutOfStockCount(): Flow<Int>
    @Query("SELECT COALESCE(SUM(CAST(currentStock * purchasePrice AS INTEGER)), 0) FROM products WHERE isDeleted = 0 AND currentStock > 0")
    fun observeStockValueAtCost(): Flow<Long>
    @Query("SELECT COALESCE(SUM(CAST(currentStock * sellingPrice AS INTEGER)), 0) FROM products WHERE isDeleted = 0 AND currentStock > 0")
    fun observeStockValueAtSelling(): Flow<Long>
}

@Dao
interface StockHistoryDao {
    @Insert suspend fun insert(h: StockHistoryEntity): Long
    @Insert suspend fun insertAll(list: List<StockHistoryEntity>)
    @Query("SELECT * FROM stock_history WHERE (:productId = 0 OR productId = :productId) ORDER BY createdAt DESC, id DESC LIMIT :limit")
    fun observe(productId: Long, limit: Int): Flow<List<StockHistoryEntity>>
}

@Dao
interface CustomerDao {
    @Insert suspend fun insert(c: CustomerEntity): Long
    @Update suspend fun update(c: CustomerEntity)
    @Query("SELECT * FROM customers WHERE id = :id") suspend fun getById(id: Long): CustomerEntity?
    @Query("UPDATE customers SET isDeleted = 1 WHERE id = :id") suspend fun softDelete(id: Long)
    @Query(
        """SELECT * FROM customers WHERE isDeleted = 0
           AND (:q = '' OR name LIKE '%' || :q || '%' OR mobile LIKE '%' || :q || '%')
           ORDER BY name COLLATE NOCASE"""
    )
    fun observe(q: String): Flow<List<CustomerEntity>>
}

@Dao
interface SupplierDao {
    @Insert suspend fun insert(s: SupplierEntity): Long
    @Update suspend fun update(s: SupplierEntity)
    @Query("SELECT * FROM suppliers WHERE id = :id") suspend fun getById(id: Long): SupplierEntity?
    @Query("SELECT * FROM suppliers WHERE (:q = '' OR name LIKE '%' || :q || '%') ORDER BY name COLLATE NOCASE")
    fun observe(q: String): Flow<List<SupplierEntity>>
}

@Dao
interface SaleDao {
    @Insert suspend fun insertSale(s: SaleEntity): Long
    @Update suspend fun updateSale(s: SaleEntity)
    @Insert suspend fun insertItems(items: List<SaleItemEntity>)
    @Query("DELETE FROM sale_items WHERE saleId = :saleId") suspend fun deleteItems(saleId: Long)
    @Query("SELECT * FROM sales WHERE id = :id") suspend fun getSale(id: Long): SaleEntity?
    @Query("SELECT * FROM sale_items WHERE saleId = :saleId") suspend fun getItems(saleId: Long): List<SaleItemEntity>

    @Query(
        """SELECT * FROM sales
           WHERE createdAt BETWEEN :from AND :to
           AND (:q = '' OR invoiceNumber LIKE '%' || :q || '%' OR customerName LIKE '%' || :q || '%')
           AND (:customerId = 0 OR customerId = :customerId)
           ORDER BY createdAt DESC, id DESC"""
    )
    fun observe(from: Long, to: Long, q: String, customerId: Long): Flow<List<SaleEntity>>

    @Query("SELECT COALESCE(SUM(total), 0) FROM sales WHERE createdAt BETWEEN :from AND :to")
    fun observeSalesTotal(from: Long, to: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(profit), 0) FROM sales WHERE createdAt BETWEEN :from AND :to")
    fun observeProfit(from: Long, to: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(cashPaid + upiPaid), 0) FROM sales WHERE createdAt BETWEEN :from AND :to")
    fun observePaidOnSales(from: Long, to: Long): Flow<Long>
}

@Dao
interface PurchaseDao {
    @Insert suspend fun insertPurchase(p: PurchaseEntity): Long
    @Update suspend fun updatePurchase(p: PurchaseEntity)
    @Insert suspend fun insertItems(items: List<PurchaseItemEntity>)
    @Query("DELETE FROM purchase_items WHERE purchaseId = :id") suspend fun deleteItems(id: Long)
    @Query("SELECT * FROM purchases WHERE id = :id") suspend fun getPurchase(id: Long): PurchaseEntity?
    @Query("SELECT * FROM purchase_items WHERE purchaseId = :id") suspend fun getItems(id: Long): List<PurchaseItemEntity>

    @Query(
        """SELECT * FROM purchases
           WHERE purchaseDate BETWEEN :from AND :to
           AND (:q = '' OR supplierName LIKE '%' || :q || '%' OR supplierBillNumber LIKE '%' || :q || '%')
           ORDER BY purchaseDate DESC, id DESC"""
    )
    fun observe(from: Long, to: Long, q: String): Flow<List<PurchaseEntity>>

    @Query("SELECT COALESCE(SUM(total), 0) FROM purchases WHERE purchaseDate BETWEEN :from AND :to")
    fun observeTotal(from: Long, to: Long): Flow<Long>

    @Insert suspend fun insertPriceHistory(h: PurchasePriceHistoryEntity)
    @Query("DELETE FROM purchase_price_history WHERE purchaseId = :purchaseId")
    suspend fun deletePriceHistoryForPurchase(purchaseId: Long)
    @Query("SELECT * FROM purchase_price_history WHERE productId = :productId ORDER BY date DESC, id DESC")
    fun observePriceHistory(productId: Long): Flow<List<PurchasePriceHistoryEntity>>
}

@Dao
interface CustomerPaymentDao {
    @Insert suspend fun insert(p: CustomerPaymentEntity): Long
    @Query("SELECT * FROM customer_payments WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun observeForCustomer(customerId: Long): Flow<List<CustomerPaymentEntity>>
    @Query("SELECT COALESCE(SUM(amount), 0) FROM customer_payments WHERE createdAt BETWEEN :from AND :to")
    fun observeTotal(from: Long, to: Long): Flow<Long>

    /** Outstanding = sum of bill credits - sum of payments received. */
    @Query(
        """SELECT (SELECT COALESCE(SUM(creditAmount), 0) FROM sales WHERE customerId = :customerId)
                - (SELECT COALESCE(SUM(amount), 0) FROM customer_payments WHERE customerId = :customerId)"""
    )
    fun observeOutstanding(customerId: Long): Flow<Long>

    @Query(
        """SELECT (SELECT COALESCE(SUM(creditAmount), 0) FROM sales WHERE customerId IS NOT NULL)
                - (SELECT COALESCE(SUM(amount), 0) FROM customer_payments)"""
    )
    fun observeTotalOutstanding(): Flow<Long>
}

@Dao
abstract class InvoiceCounterDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun save(c: InvoiceCounterEntity)
    @Query("SELECT * FROM invoice_counter WHERE id = 1") abstract suspend fun get(): InvoiceCounterEntity?
    @Query("SELECT * FROM invoice_counter WHERE id = 1") abstract fun observe(): Flow<InvoiceCounterEntity?>

    /** Call inside the same transaction that saves the sale, so a failed sale never burns a number. */
    @Transaction
    open suspend fun takeNextNumber(): String {
        val c = get() ?: InvoiceCounterEntity()
        save(c.copy(nextNumber = c.nextNumber + 1))
        return c.prefix + c.nextNumber.toString().padStart(c.padding, '0')
    }
}

@Dao
interface BusinessProfileDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(p: BusinessProfileEntity)
    @Query("SELECT * FROM business_profile WHERE id = 1") fun observe(): Flow<BusinessProfileEntity?>
    @Query("SELECT * FROM business_profile WHERE id = 1") suspend fun get(): BusinessProfileEntity?
}

@Dao
interface AppSettingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(s: AppSettingEntity)
    @Query("SELECT value FROM app_settings WHERE `key` = :key") suspend fun get(key: String): String?
    @Query("SELECT value FROM app_settings WHERE `key` = :key") fun observe(key: String): Flow<String?>
}
